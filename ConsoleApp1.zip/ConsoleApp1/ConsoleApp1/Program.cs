﻿using System;

class Program
{
    // Task 1: Understanding Types and Memory Usage
    static void PrintTypeInfo()
    {
        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "Type", "Size (bytes)", "Range");
        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "----", "-----------", "-----");

        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "sbyte", sizeof(sbyte), $"{sbyte.MinValue} to {sbyte.MaxValue}");
        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "byte", sizeof(byte), $"{byte.MinValue} to {byte.MaxValue}");
        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "short", sizeof(short), $"{short.MinValue} to {short.MaxValue}");
        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "ushort", sizeof(ushort), $"{ushort.MinValue} to {ushort.MaxValue}");
        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "int", sizeof(int), $"{int.MinValue} to {int.MaxValue}");
        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "uint", sizeof(uint), $"{uint.MinValue} to {uint.MaxValue}");
        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "long", sizeof(long), $"{long.MinValue} to {long.MaxValue}");
        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "ulong", sizeof(ulong), $"{ulong.MinValue} to {ulong.MaxValue}");
        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "float", sizeof(float), $"{float.MinValue} to {float.MaxValue}");
        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "double", sizeof(double), $"{double.MinValue} to {double.MaxValue}");
        Console.WriteLine("{0,-15}{1,-10}{2,-20}", "decimal", sizeof(decimal), $"{decimal.MinValue} to {decimal.MaxValue}");
    }

    // Task 2: Convert Centuries to Other Time Units
    static void ConvertCenturiesToTimeUnits()
    {
        Console.Write("Enter number of centuries: ");
        int centuries = int.Parse(Console.ReadLine());

        long years = centuries * 100;
        long days = years * 365;
        long hours = days * 24;
        long minutes = hours * 60;
        long seconds = minutes * 60;
        long milliseconds = seconds * 1000;
        long microseconds = milliseconds * 1000;
        long nanoseconds = microseconds * 1000;

        Console.WriteLine($"{centuries} centuries = {years} years = {days} days = {hours} hours = {minutes} minutes = {seconds} seconds = {milliseconds} milliseconds = {microseconds} microseconds = {nanoseconds} nanoseconds");
    }

    // Task 3: FizzBuzz Game
    static void FizzBuzz()
    {
        for (int i = 1; i <= 100; i++)
        {
            if (i % 3 == 0 && i % 5 == 0)
                Console.WriteLine("FizzBuzz");
            else if (i % 3 == 0)
                Console.WriteLine("Fizz");
            else if (i % 5 == 0)
                Console.WriteLine("Buzz");
            else
                Console.WriteLine(i);
        }
    }

    // Task 4: Random Number Guessing Game
    static void GuessTheNumber()
    {
        Random random = new Random();
        int correctNumber = random.Next(1, 4); // Generates a number between 1 and 3

        Console.Write("Guess a number (1, 2, or 3): ");
        int guessedNumber = int.Parse(Console.ReadLine());

        if (guessedNumber < 1 || guessedNumber > 3)
        {
            Console.WriteLine("Invalid guess! Number must be between 1 and 3.");
        }
        else if (guessedNumber == correctNumber)
        {
            Console.WriteLine("Correct!");
        }
        else if (guessedNumber < correctNumber)
        {
            Console.WriteLine("Too low!");
        }
        else
        {
            Console.WriteLine("Too high!");
        }
    }

    // Task 5: Print-a-Pyramid
    static void PrintPyramid()
    {
        int rows = 5;

        for (int i = 1; i <= rows; i++)
        {
            for (int j = i; j < rows; j++)  // Print spaces
                Console.Write(" ");
            
            for (int j = 1; j <= (2 * i - 1); j++)  // Print stars
                Console.Write("*");
            
            Console.WriteLine();
        }
    }

    // Task 6: Calculate Days Since Birth Date
    static void DaysSinceBirth()
    {
        Console.Write("Enter your birthdate (yyyy-mm-dd): ");
        DateTime birthDate = DateTime.Parse(Console.ReadLine());
        DateTime today = DateTime.Now;

        TimeSpan age = today - birthDate;
        Console.WriteLine($"You are {age.Days} days old.");

        // Extra Credit: 10,000 day anniversary
        DateTime nextAnniversary = birthDate.AddDays(10000);
        Console.WriteLine($"Your next 10,000 day anniversary is on {nextAnniversary:yyyy-MM-dd}.");
    }

    // Task 7: Greet User Based on Time of Day
    static void GreetUser()
    {
        DateTime currentTime = DateTime.Now;

        if (currentTime.Hour < 12)
            Console.WriteLine("Good Morning");
        else if (currentTime.Hour < 18)
            Console.WriteLine("Good Afternoon");
        else if (currentTime.Hour < 22)
            Console.WriteLine("Good Evening");
        else
            Console.WriteLine("Good Night");
    }

    // Task 8: Count by 1s, 2s, 3s, and 4s
    static void CountIncrements()
    {
        for (int i = 1; i <= 4; i++)
        {
            for (int j = 0; j <= 24; j += i)
            {
                Console.Write(j + " ");
            }
            Console.WriteLine();
        }
    }

    static void Main()
    {
        // Call the functions below to run each task.
        Console.WriteLine("Task 1: Type Information");
        PrintTypeInfo();
        
        Console.WriteLine("\nTask 2: Convert Centuries to Time Units");
        ConvertCenturiesToTimeUnits();
        
        Console.WriteLine("\nTask 3: FizzBuzz Game");
        FizzBuzz();
        
        Console.WriteLine("\nTask 4: Guess The Number");
        GuessTheNumber();
        
        Console.WriteLine("\nTask 5: Print-a-Pyramid");
        PrintPyramid();
        
        Console.WriteLine("\nTask 6: Days Since Birth");
        DaysSinceBirth();
        
        Console.WriteLine("\nTask 7: Greet User Based on Time");
        GreetUser();
        
        Console.WriteLine("\nTask 8: Count in Increments");
        CountIncrements();
    }
}
