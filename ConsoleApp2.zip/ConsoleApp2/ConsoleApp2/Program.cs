﻿using System;

class Program
{
    // Task 2: DisplayBoxingUnboxing
    static void DisplayBoxingUnboxing()
    {
        int number = 123;
        object obj = number; // Boxing
        int unboxedNumber = (int)obj; // Unboxing
        Console.WriteLine($"Boxed: {obj}, Unboxed: {unboxedNumber}");
    }

    // Task 4: Division by Zero Handling (Fixed)
    static void DivisionByZero()
    {
        int denominator = 10;

        if (denominator == 0)
        {
            Console.WriteLine("Error: Cannot divide by zero.");
        }
        else
        {
            int result = 10 / denominator;
            Console.WriteLine($"Result: {result}");
        }
    }

    // Task 9: Random Number Guessing Game (Fixed)
    static void GuessTheNumber()
    {
        Random random = new Random();
        int correctNumber = random.Next(1, 4); // Generates 1, 2, or 3

        Console.WriteLine("Guess a number between 1 and 3:");
        string userInput = Console.ReadLine();
        if (string.IsNullOrEmpty(userInput)) // Check for null or empty input
        {
            Console.WriteLine("Invalid input. Please enter a valid number.");
            return;
        }

        bool isValid = int.TryParse(userInput, out int guessedNumber);
        if (!isValid)
        {
            Console.WriteLine("Invalid input. Please enter a valid number.");
            return;
        }

        if (guessedNumber < 1 || guessedNumber > 3)
        {
            Console.WriteLine("Your guess is outside the valid range.");
        }
        else if (guessedNumber < correctNumber)
        {
            Console.WriteLine("Too low!");
        }
        else if (guessedNumber > correctNumber)
        {
            Console.WriteLine("Too high!");
        }
        else
        {
            Console.WriteLine("Correct!");
        }
    }

    // Task 10: Days Since Birth (Fixed)
    static void DaysSinceBirth()
    {
        Console.Write("Enter your birthdate (yyyy-mm-dd): ");
        string input = Console.ReadLine();

        if (string.IsNullOrEmpty(input))
        {
            Console.WriteLine("Invalid input. Please enter a valid date.");
            return;
        }

        if (DateTime.TryParse(input, out DateTime birthDate))
        {
            DateTime today = DateTime.Now;

            TimeSpan age = today - birthDate;
            Console.WriteLine($"You are {age.Days} days old.");

            // Extra Credit: 10,000 day anniversary
            DateTime nextAnniversary = birthDate.AddDays(10000);
            Console.WriteLine($"Your next 10,000 day anniversary is on {nextAnniversary:yyyy-MM-dd}.");
        }
        else
        {
            Console.WriteLine("Invalid date format.");
        }
    }

    // Main method to execute all tasks
    static void Main()
    {
        DivisionByZero();
        GuessTheNumber();
        DaysSinceBirth();
    }
}


